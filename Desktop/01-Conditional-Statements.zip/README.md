# Conditional Statements

In this activity, you will use conditional statements to determine which alert will pop up on the screen.

## Instructions

* Open [index.html](Unsolved/index.html) in your IDE and create a website from scratch that asks users if they eat meat.

  * If they respond with "OK", alert the following to the page: "Here’s a cheese burger!"

  * If they respond with "Cancel", alert the following to the page: "Here’s a veggie burger!"

---
© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand. Confidential and Proprietary. All Rights Reserved.